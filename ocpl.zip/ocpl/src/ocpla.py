import struct
from ocpla_f import *
from sys import argv

# Take in command line arguments, input and output files.
in_file = argv[1]
out_file = argv[2]

# Input & output files
input = open(in_file,'r')
output = open(out_file,"wb")

in_content = input.readlines()

al,sl = "","" # active line, second line

# Data to file array
dtf = []

for line in in_content: # Loop through every line in given file
    al = line.split()   # Split the active line from file into array stored in al
    
    if al: # If active line contains anything
        if "$" in al[0]:
            dtf.extend([999999999,855435,int(al[0].strip("$"))])

        match al[0]:                     # CHECK FIRST STRINGS
            case "mov" | "Mov" | "MOV":  # MOVE INSTRUCTIONS  ----
                sl = al[1].split(","[0]) # Split the first string in al array based on it's comma
                
                # MOV #,R
                if "#" in sl[0] and is_register(sl[1]):dtf.extend([100,return_ior(sl[1]),int(sl[0].strip("#"))])

                # MOV $,R
                if "$" in sl[0] and "+p" not in sl[0] and is_register(sl[1]):dtf.extend([101,int(sl[0].strip("$")),return_ior(sl[1])])

                # MOV R,R
                if is_register(sl[0]) and is_register(sl[1]):dtf.extend([102,return_ior(sl[0]),return_ior(sl[1])])

                # MOV R,$
                if is_register(sl[0]) and "$" in sl[1] and "+p" not in sl[1]:dtf.extend([103,return_ior(sl[0]),int(sl[1].strip("$"))])

                # MOV R,$+P
                if is_register(sl[0]) and "$" in sl[1] and "+p" in sl[1]:dtf.extend([104,return_ior(sl[0]),int(sl[1].strip("$+p"))])

                # MOV $+P,R
                if "$" in sl[0] and "+p" in sl[0] and is_register(sl[1]):dtf.extend([105,int(sl[0].strip("$+p")),return_ior(sl[1])])

            # ADD R1,R2 (R2 = R1 + R2)
            case "add" | "Add" | "ADD":
                sl = al[1].split(","[0])
                dtf.extend([106,return_ior(sl[0]),return_ior(sl[1])])

            # SUB R1,R2 (R1 = R1 - R2)
            case "sub" | "Sub" | "SUB":
                sl = al[1].split(","[0])
                dtf.extend([107,return_ior(sl[0]),return_ior(sl[1])])

            # INC R
            case "inc" | "Inc" | "INC":dtf.extend([108,return_ior(al[1])])

            # DEC R
            case "dec" | "Dec" | "DEC":dtf.extend([109,return_ior(al[1])])

            # COMPARE INSTRUCTIONS
            case "cmp" | "Cmp" | "CMP":
                sl = al[1].split(","[0])

                # CMP R,D
                if is_register(sl[0]) and "#" in sl[1]:dtf.extend([110,return_ior(sl[0]),int(sl[1].strip("#"))])
                
                # CMP R,$
                if is_register(sl[0]) and "$" in sl[1]:dtf.extend([111,return_ior(sl[0]),int(sl[1].strip("$"))])

            # JMP $
            case "jmp" | "Jmp" | "JMP":dtf.extend([112,int(al[1].strip("$"))])

            # JSR $
            case "jsr" | "Jsr" | "JSR":dtf.extend([113,int(al[1].strip("$"))])

            # RTS
            case "rts" | "Rts" | "RTS":dtf.extend([114])

            # BEQ $
            case "beq" | "Beq" | "BEQ":dtf.extend([115,int(al[1].strip("$"))])

            # BNE $
            case "bne" | "Bne" | "BNE":dtf.extend([116,int(al[1].strip("$"))])

            # PSH R
            case "psh" | "Psh" | "PSH":dtf.extend([117,return_ior(al[1])])

            # PUL R
            case "pul" | "Pul" | "PUL":dtf.extend([118,return_ior(al[1])])






# Write out data to binary file
for x in range(len(dtf)):
    if dtf[x] == 999999999 and dtf[x+1] == 855435:output.seek(4 * dtf[x+2],1)
    output.write(struct.pack("<i",dtf[x]))
output.close()