def is_register(given_char):
    match given_char:
        case "x" | "X" | "y" | "Y" | "t" | "T" | "p" | "P" | "u" | "U":return True

def return_ior(given_char):
    match given_char:
        case "x" | "X":return 1
        case "y" | "Y":return 2
        case "t" | "T":return 3
        case "p" | "P":return 4
        case "u" | "U":return 5
    