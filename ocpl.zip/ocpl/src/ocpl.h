/*_________________________
OCPL - Programming Language
Copyright (c) 2022-2025
___________________________
THIS: ocpl.h
VERSION 1.0

Last modified : Tue May 13 2025
*/

#ifndef OCPL_H
#define OCPL_H

#include <stdbool.h>

void core_cycle();
void core_decode();

typedef struct {
    int x,y,t,p,u; // General Registers
} gregisters;
gregisters gr_init();

typedef struct {
    bool a,e,m,o,i; // Flag Registers
} fregisters;
fregisters fr_init();

typedef struct {
    int pc; // Program Counter
    int sp; // Stack Pointer
} pointers;
pointers pt_init();

typedef struct {
    gregisters greg;  // General Registers
    fregisters freg;  // Flag Registers
    pointers pntr;    // Pointers
    int stack[65535]; // Stack
} core;
core core_init();


// OCPL MEMORY
#define max_mem 524288

// OCPL OPCODES
#define o_movd  100 // MOV #,R    MOVE DECIMAL INTO REGISTER
#define o_mova  101 // MOV $,R    MOVE ADDRESS INTO REGISTER
#define o_movr  102 // MOV R1,R2  MOVE REGISTER INTO REGISTER (R2 = R1)
#define o_movm  103 // MOV R,$    MOVE REGISTER INTO MEMORY
#define o_movmw 104 // MOV R,$+P  MOVE REGISTER INTO MEMORY(ADDR + REG) 
#define o_movaw 105 // MOV $+P,R  MOVE MEMORY(ADDR + REG) INTO REGISTER

#define o_add 106 // ADD R1,R2  ADD REGISTER INTO REGISTER (R2 = R1 + R2)
#define o_sub 107 // SUB R1,R2  SUB REGISTER FROM REGISTER (R1 = R1 - R2)
#define o_inc 108 // INC R      INCREMENT REGISTER BY 1
#define o_dec 109 // DEC R      DECREMENT REGISTER BY 1

#define o_cmp 110  // CMP R,D  COMPARE REGISTER WITH DECIMAL
#define o_cmpa 111 // CMP R,$  COMPARE REGISTER WITH ADDRESS

#define o_jmp 112 // JMP $  JUMP TO ADDRESS
#define o_jsr 113 // JSR $  JUMP TO ADDRESS SAVE PREV ADDR INTO STACK
#define o_rts 114 // RTS    RETURN TO PREVIOUS ADDRESS

#define o_beq 115 // BEQ $  BRANCH ON EQUAL
#define o_bne 116 // BNE $  BRANCH ON NOT EQUAL

#define o_psh 117 // PSH R  PUSH REGISTER TO STACK
#define o_pul 118 // PUL R  PULL STACK TO REGISTER

void core_movd();
void core_mova();
void core_movr();
void core_movm();
void core_movmw();
void core_movaw();
void core_add();
void core_sub();
void core_inc();
void core_dec();
void core_cmp();
void core_cmpa();
void core_jmp();
void core_jsr();
void core_rts();
void core_beq();
void core_bne();
void core_psh();
void core_pul();

void core_setReg(int,int);
void core_setMem(int,int);
int core_returnReg(int);

void organize_memory();






#endif