/*_________________________
OCPL - Programming Language
Copyright (c) 2022-2025
___________________________
THIS: ocpl.h
VERSION 1.0

Last modified : Tue May 13 2025
*/

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "ocpl.h"

int mem[max_mem];
core ocpl_c1;

int main(int argc, char *argv[]) {
    FILE *s_file = fopen(argv[1],"rb");
    if (!s_file) {
        perror("Failed to open file");
        return 1;
    }

    size_t file_content = fread(mem,sizeof(int),524288,s_file);
    fclose(s_file);

    ocpl_c1 = core_init();

    while(ocpl_c1.freg.a) {
        core_cycle();

        printf("------\n");
        printf("X: %d  Y: %d T: %d P: %d U: %d\n", ocpl_c1.greg.x, ocpl_c1.greg.y,ocpl_c1.greg.t,ocpl_c1.greg.p,ocpl_c1.greg.u);    
        printf("PC: %d SP: %d\n",ocpl_c1.pntr.pc,ocpl_c1.pntr.sp);
        printf("A: %d E: %d M: %d O: %d I: %d\n",ocpl_c1.freg.a,ocpl_c1.freg.e,ocpl_c1.freg.m,ocpl_c1.freg.o,ocpl_c1.freg.i);
        }
    


    return 0;
}

gregisters gr_init() {
    gregisters return_d;
    return_d.x = 0;
    return_d.y = 0;
    return_d.t = 0;
    return_d.p = 0;
    return_d.u = 0;

    return return_d;
}

fregisters fr_init() {
    fregisters return_d;
    return_d.a = true;
    return_d.e = false;
    return_d.m = false;
    return_d.o = false;
    return_d.i = false;

    return return_d;
}

pointers pt_init() {
    pointers return_d;
    return_d.pc = 0;
    return_d.sp = 0;

    return return_d;
}

core core_init() {
    core return_d;
    return_d.greg = gr_init();
    return_d.freg = fr_init();
    return_d.pntr = pt_init();
    for (int i = 0; i < 65535;i++) {
        return_d.stack[i] = 0;
    }

    return return_d;
}

void load_file() {

}

void core_cycle() {
    core_decode();
}

void core_decode() {
    switch (mem[ocpl_c1.pntr.pc]) {
        case o_movd:core_movd();break;
        case o_mova:core_mova();break;
        case o_movr:core_movr();break;
        case o_movm:core_movm();break;
        case o_movmw:core_movmw();break;
        case o_movaw:core_movaw();break;
        
        case o_add:core_add();break;
        case o_sub:core_sub();break;
        case o_inc:core_inc();break;
        case o_dec:core_dec();break;

        case o_cmp:core_cmp();break;
        case o_cmpa:core_cmpa();break;

        case o_jmp:core_jmp();break;
        case o_jsr:core_jsr();break;
        case o_rts:core_rts();break;

        case o_beq:core_beq();break;
        case o_bne:core_bne();break;
        case o_psh:core_psh();break;
        case o_pul:core_pul();break;
        default:ocpl_c1.freg.a = false;break;
    }
}

void core_movd() { // MOV #,R
    core_setReg(mem[ocpl_c1.pntr.pc+1],mem[ocpl_c1.pntr.pc+2]);
    ocpl_c1.pntr.pc += 3;
}

void core_mova() { // MOV $,R
    core_setReg(mem[ocpl_c1.pntr.pc+2],mem[mem[ocpl_c1.pntr.pc+1]]);
    ocpl_c1.pntr.pc+=3;
}

void core_movr() { // MOV R1,R2
    core_setReg(mem[ocpl_c1.pntr.pc+2],core_returnReg(mem[ocpl_c1.pntr.pc+1]));
    ocpl_c1.pntr.pc+=3;
}

void core_movm() { // MOV R,$
    core_setMem(mem[ocpl_c1.pntr.pc+2],core_returnReg(mem[ocpl_c1.pntr.pc+1]));
    ocpl_c1.pntr.pc+=3;
    
}

void core_movmw() { // MOV R,$+P
    core_setMem((mem[ocpl_c1.pntr.pc+2]+ocpl_c1.greg.p),core_returnReg(mem[ocpl_c1.pntr.pc+1]));
    ocpl_c1.pntr.pc+=3;
}

void core_movaw() { // MOV $+P,R
    core_setReg(mem[ocpl_c1.pntr.pc+2],mem[mem[ocpl_c1.pntr.pc+1]+ocpl_c1.greg.p]);
    ocpl_c1.pntr.pc+=3;
}

void core_add() { // ADD R1,R2 (R2 = R1 + R2)
    core_setReg(mem[ocpl_c1.pntr.pc+2],(core_returnReg(mem[ocpl_c1.pntr.pc+1])+core_returnReg(mem[ocpl_c1.pntr.pc+2])));
    ocpl_c1.pntr.pc+=3;
}

void core_sub() { // SUB R1,R2 (R1 = R1 - R2)
    core_setReg(mem[ocpl_c1.pntr.pc+1],(core_returnReg(mem[ocpl_c1.pntr.pc+1])-core_returnReg(mem[ocpl_c1.pntr.pc+2])));
    ocpl_c1.pntr.pc+=3;
}

void core_inc() { // INC R
    core_setReg(mem[ocpl_c1.pntr.pc+1],core_returnReg(mem[ocpl_c1.pntr.pc+1])+1);
    ocpl_c1.pntr.pc+=2;
}

void core_dec() { // DEC R
    core_setReg(mem[ocpl_c1.pntr.pc+1],core_returnReg(mem[ocpl_c1.pntr.pc+1])-1);
    ocpl_c1.pntr.pc+=2;
}

void core_cmp() { // CMP R,D
    if (core_returnReg(mem[ocpl_c1.pntr.pc+1]) == mem[ocpl_c1.pntr.pc+2])
        ocpl_c1.freg.e = true;
    ocpl_c1.pntr.pc+=3;
}

void core_cmpa() { // CMP R,$
    if (core_returnReg(mem[ocpl_c1.pntr.pc+1])==mem[mem[ocpl_c1.pntr.pc+2]])
        ocpl_c1.freg.e = true;
    ocpl_c1.pntr.pc+=3;
}

void core_jmp() { // JMP $
    ocpl_c1.pntr.pc = mem[ocpl_c1.pntr.pc+1];
}

void core_jsr() { // JSR $
    ocpl_c1.stack[ocpl_c1.pntr.sp] = ocpl_c1.pntr.pc;ocpl_c1.pntr.sp++;
    ocpl_c1.pntr.pc = mem[ocpl_c1.pntr.pc+1];
}

void core_rts() { // RTS
    ocpl_c1.pntr.sp--;ocpl_c1.pntr.pc = ocpl_c1.stack[ocpl_c1.pntr.sp];
}

void core_beq() { // BEQ $
    if (ocpl_c1.freg.e) {
        ocpl_c1.pntr.pc = mem[ocpl_c1.pntr.pc+1];
        ocpl_c1.freg.e = false;
    }
    else
        ocpl_c1.pntr.pc+=2;
}

void core_bne() { // BNE $
    if (ocpl_c1.freg.e)
        ocpl_c1.pntr.pc+=2;
    else
        ocpl_c1.pntr.pc = mem[ocpl_c1.pntr.pc+1];
}

void core_psh() { // PSH R
    ocpl_c1.stack[ocpl_c1.pntr.sp] = core_returnReg(mem[ocpl_c1.pntr.pc+1]);ocpl_c1.pntr.sp++;
    ocpl_c1.pntr.pc+=2;
}

void core_pul() { // PUL R
    ocpl_c1.pntr.sp--;core_setReg(ocpl_c1.pntr.pc+1,ocpl_c1.stack[ocpl_c1.pntr.sp]);
    ocpl_c1.pntr.pc+=2;
}

void core_setReg(int r, int v) {
    switch (r) {
        case 1:ocpl_c1.greg.x = v;break;
        case 2:ocpl_c1.greg.y = v;break;
        case 3:ocpl_c1.greg.t = v;break;
        case 4:ocpl_c1.greg.p = v;break;
        case 5:ocpl_c1.greg.u = v;break;
    }
}

void core_setMem(int a, int v) {
    mem[a] = v;
}

int core_returnReg(int r) {
    switch (r) {
        case 1:return ocpl_c1.greg.x;break;
        case 2:return ocpl_c1.greg.y;break;
        case 3:return ocpl_c1.greg.t;break;
        case 4:return ocpl_c1.greg.p;break;
        case 5:return ocpl_c1.greg.u;break;
    }
    return 0;
}

void organize_memory() {
    for (int i = 0; i<max_mem;i++) {
        if (mem[i] == 999999999 && mem[i+1] == 3845223) {
            
        }
    }

}





